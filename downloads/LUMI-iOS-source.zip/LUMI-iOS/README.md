# LUMI iOS

Mac 설치 방법은 ios/README.md를 확인하세요.

Xcode에서 ios/Lumi.xcodeproj를 여세요.
