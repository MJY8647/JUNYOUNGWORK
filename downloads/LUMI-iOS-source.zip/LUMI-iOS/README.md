# LUMI iOS

설치와 Mac 빌드는 ios/README.md를 확인하세요. Xcode 프로젝트는 ios/Lumi.xcodeproj입니다. 아직 서명한 IPA가 아닌 소스 프로젝트입니다.
