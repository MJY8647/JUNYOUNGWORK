# iOS 검증 상태

2026-10-14 기준입니다. 이 기록은 기존 Android 실행 검증과 별도입니다.

| 검사 | 결과 |
|---|---|
| Swift 6.0.3 Linux 실제 컴파일 및 XCTest | 픽셀 엔진 11개 테스트 통과, 실패 0 |
| Swift 컴파일러 `-frontend -parse -swift-version 5` | 앱·테스트 소스 문법 검사 통과 |
| Swift 문법 트리 및 Xcode 프로젝트 구조 검사 | Swift 파일 9개, 프로젝트 객체 43개·소스 참조·공유 Scheme·아이콘 자산 확인 |
| Mac 테스트 실행 스크립트 | Bash 구문 확인 |
| Xcode Apple SDK 빌드 | **통과 — [macOS GitHub Actions](https://github.com/MJY8647/JUNYOUNGWORK/actions/runs/38543214330)** |
| iOS XCTest 대상(15개 테스트) | **시뮬레이터 test 단계 통과** |
| 사진 선택·저장 권한 및 실제 JPEG 출력 | **iOS에서 미실행** |
| 영상 재생·구간 자르기·음소거 및 MP4 출력 | **iOS에서 미실행** |
| 실제 iPhone 설치, 서명, TestFlight | **미실행 — 사용자 Mac/Apple 계정 필요** |

macOS 검사 소스 커밋은 `02c691f`이며, Build app and execute iOS unit tests 단계와 결과 업로드 단계가 성공했습니다. 공개 작업 상태 기록은 [macos-ci-result.json](macos-ci-result.json)에 있습니다. 전체 로그와 XCTest 결과 번들은 위 Actions 실행에서 확인할 수 있습니다.

Linux 결과 로그는 [pixel-tests-linux.txt](pixel-tests-linux.txt)입니다. XCTest의 `Executed 11 tests, with 0 failures`가 검증 결과입니다. 끝에 표시되는 별도 Swift Testing 러너의 0개 테스트는 추가 테스트가 없다는 뜻이며, 검증 수로 계산하지 않습니다.

검증에 사용한 Swift 공식 Docker 이미지 digest:

```text
swift@sha256:b394f699c1844fabf5c01d8a5673639141dc007f500661a4fa56f4ba1f23d87b
```

테스트 실행은 네트워크를 끄고 저장소를 읽기 전용으로 마운트한 컨테이너에서 수행했습니다. 앱 서버나 서명 키를 사용하지 않았습니다.

Mac에서 저장소 루트의 `bash scripts/test-ios-mac.sh`를 실행하면 Apple SDK 빌드와 iOS 전용 이미지 브리지·회전·자르기·브러시 좌표·콜라주 검증을 실행할 수 있습니다. 이 테스트를 실행해도 사진/영상 저장 권한과 실제 기기의 전체 UI 검증이 자동으로 완료되지는 않습니다.

## 실제 아이폰에서 확인할 순서

1. 샘플 사진과 본인 사진을 각각 불러옵니다. 세로·가로·HEIC·JPEG 사진의 방향을 확인합니다.
2. 각 슬라이더와 피부·잡티·부분 형태 브러시를 적용하고 원본 비교, 되돌리기/다시 실행을 확인합니다.
3. 회전·반전·비율 자르기·문구·프레임 후 저장하고 사진 앱에서 결과와 방향을 확인합니다.
4. 2장과 9장 콜라주, 세 레이아웃을 만들고 결과를 저장합니다.
5. 짧은 MP4/MOV 영상의 시작·끝을 조절해 저장하고, 음소거 버전에서 소리가 없는지 확인합니다.
6. 사진 저장 권한을 거절한 경우 안내가 나오는지, 설정에서 허용한 뒤 저장이 되는지 확인합니다.

Apple SDK 빌드와 단위 테스트는 통과했지만 실기기 전체 동작이 검증된 앱은 아닙니다. 상세 설치 방법은 [README.md](README.md)를 확인하세요.
